function getCookie(name) {
  let cookieValue = null;
  if (document.cookie && document.cookie !== "") {
    const cookies = document.cookie.split(";");
    for (const cookie of cookies) {
      const c = cookie.trim();
      if (c.startsWith(name + "=")) {
        cookieValue = decodeURIComponent(c.substring(name.length + 1));
        break;
      }
    }
  }
  return cookieValue;
}

async function postAction(url) {
  const csrftoken = getCookie("csrftoken");

  const response = await fetch(url, {
    method: "POST",
    credentials: "same-origin",
    headers: {
      "X-Requested-With": "XMLHttpRequest",
      "X-CSRFToken": csrftoken,
    },
  });

  if (!response.ok) {
    throw new Error(`Request failed: ${response.status}`);
  }

  return response.json();
}

// === DOM Elements ===
const logBox = document.querySelector(".terminal");
const batchState = document.getElementById("batch-state");
const progressValue = document.getElementById("progress-value");
const cpuValue = document.getElementById("cpu-value");
const modemState = document.getElementById("modem-state");
const statusTableBody = document.querySelector(".status-panel tbody");
const scriptGrid = document.getElementById("scriptGrid");

const timerInput = document.getElementById("timer-input");
const timerUnit = document.getElementById("timer-unit");
const timerDisplay = document.getElementById("timer-display");

// === Config Elements ===
const saveConfigBtn = document.getElementById("saveConfig");
const loadConfigBtn = document.getElementById("loadConfig");

let timerInterval = null;
let timerRunning = false;
let timerDurationSeconds = 0;
let timerRemainingSeconds = 0;
let autoCycleEnabled = false;
let timerWasStoppedManually = false;

let lastLogCount = 0;

// === Config Management ===
const CONFIG_KEY = "vikrant_scraper_config";

function getConfig() {
  const config = {};
  
  // Basic settings
  config.username = document.getElementById("cfg-username")?.value || "";
  config.password = document.getElementById("cfg-password")?.value || "";
  config.parentIds = document.getElementById("cfg-parent-ids")?.value || "";
  config.leadSource2 = document.getElementById("cfg-lead-source-2")?.value || "";
  
  // Advanced settings
  config.baseUrl = document.getElementById("cfg-base-url")?.value || "";
  config.loginUrl = document.getElementById("cfg-login-url")?.value || "";
  config.reportUrl = document.getElementById("cfg-report-url")?.value || "";
  config.outputPath = document.getElementById("cfg-output-path")?.value || "";
  
  config.xpathUsername = document.getElementById("cfg-xpath-username")?.value || "";
  config.xpathPassword = document.getElementById("cfg-xpath-password")?.value || "";
  config.xpathSubmit = document.getElementById("cfg-xpath-submit")?.value || "";
  config.xpathNav = document.getElementById("cfg-xpath-nav")?.value || "";
  
  config.pageSize = parseInt(document.getElementById("cfg-page-size")?.value || "100");
  config.workers = parseInt(document.getElementById("cfg-workers")?.value || "6");
  config.maxRetries = parseInt(document.getElementById("cfg-max-retries")?.value || "2");
  config.burstSize = parseInt(document.getElementById("cfg-burst-size")?.value || "3");
  
  // Delay ranges as arrays
  config.delayApiCalls = parseDelayRange("cfg-delay-api", [0.8, 1.8]);
  config.delayPageRequests = parseDelayRange("cfg-delay-page", [1.2, 2.5]);
  config.delayParentSwitch = parseDelayRange("cfg-delay-parent", [2.0, 4.0]);
  
  return config;
}

function parseDelayRange(id, defaults) {
  const value = document.getElementById(id)?.value || "";
  try {
    if (value.trim() === "") return defaults;
    const parts = value.split(",").map(v => parseFloat(v.trim()));
    return parts.length === 2 ? parts : defaults;
  } catch {
    return defaults;
  }
}

function saveConfigToStorage() {
  const config = getConfig();
  localStorage.setItem(CONFIG_KEY, JSON.stringify(config));
  addLog("✅ Config saved to browser storage");
}

function loadConfigFromStorage() {
  try {
    const saved = localStorage.getItem(CONFIG_KEY);
    if (!saved) {
      addLog("⚠️ No saved config found");
      return;
    }
    
    const config = JSON.parse(saved);
    
    // Basic
    document.getElementById("cfg-username") && (document.getElementById("cfg-username").value = config.username || "");
    document.getElementById("cfg-password") && (document.getElementById("cfg-password").value = config.password || "");
    document.getElementById("cfg-parent-ids") && (document.getElementById("cfg-parent-ids").value = config.parentIds || "");
    document.getElementById("cfg-lead-source-2") && (document.getElementById("cfg-lead-source-2").value = config.leadSource2 || "");
    
    // Advanced
    document.getElementById("cfg-base-url") && (document.getElementById("cfg-base-url").value = config.baseUrl || "");
    document.getElementById("cfg-login-url") && (document.getElementById("cfg-login-url").value = config.loginUrl || "");
    document.getElementById("cfg-report-url") && (document.getElementById("cfg-report-url").value = config.reportUrl || "");
    document.getElementById("cfg-output-path") && (document.getElementById("cfg-output-path").value = config.outputPath || "");
    
    document.getElementById("cfg-xpath-username") && (document.getElementById("cfg-xpath-username").value = config.xpathUsername || "");
    document.getElementById("cfg-xpath-password") && (document.getElementById("cfg-xpath-password").value = config.xpathPassword || "");
    document.getElementById("cfg-xpath-submit") && (document.getElementById("cfg-xpath-submit").value = config.xpathSubmit || "");
    document.getElementById("cfg-xpath-nav") && (document.getElementById("cfg-xpath-nav").value = config.xpathNav || "");
    
    document.getElementById("cfg-page-size") && (document.getElementById("cfg-page-size").value = config.pageSize || 100);
    document.getElementById("cfg-workers") && (document.getElementById("cfg-workers").value = config.workers || 6);
    document.getElementById("cfg-max-retries") && (document.getElementById("cfg-max-retries").value = config.maxRetries || 2);
    document.getElementById("cfg-burst-size") && (document.getElementById("cfg-burst-size").value = config.burstSize || 3);
    
    document.getElementById("cfg-delay-api") && (document.getElementById("cfg-delay-api").value = config.delayApiCalls?.join(", ") || "");
    document.getElementById("cfg-delay-page") && (document.getElementById("cfg-delay-page").value = config.delayPageRequests?.join(", ") || "");
    document.getElementById("cfg-delay-parent") && (document.getElementById("cfg-delay-parent").value = config.delayParentSwitch?.join(", ") || "");
    
    addLog("✅ Config loaded from storage");
  } catch (error) {
    addLog("❌ Failed to load config");
    console.error(error);
  }
}

async function generateScriptConfig() {
  const config = getConfig();
  try {
    const result = await postAction("/generate-config/");
    addLog(`Config generated: ${result.status}`);
  } catch (error) {
    addLog("Failed to generate config - check backend endpoint");
    console.error(error);
  }
}

// === Log / Timer helpers ===
function addLog(message) {
  const line = document.createElement("div");
  const now = new Date().toLocaleTimeString();
  line.textContent = `[${now}] ${message}`;
  logBox.appendChild(line);
  logBox.scrollTop = logBox.scrollHeight;
}

function formatTime(totalSeconds) {
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;
  return [hours, minutes, seconds]
    .map((v) => String(v).padStart(2, "0"))
    .join(":");
}

function getSelectedDurationSeconds() {
  const value = parseInt(timerInput.value || "0", 10);
  const unit = timerUnit.value;

  if (unit === "hours") return value * 3600;
  if (unit === "minutes") return value * 60;
  return value;
}

function updateTimerDisplay() {
  timerDisplay.textContent = formatTime(timerRemainingSeconds);
}

function stopTimerLoop() {
  if (timerInterval) {
    clearInterval(timerInterval);
    timerInterval = null;
  }
  timerRunning = false;
  autoCycleEnabled = false;
}

function stopTimerManually() {
  timerWasStoppedManually = true;
  stopTimerLoop();
  addLog("Timer stopped");
  timerRemainingSeconds = getSelectedDurationSeconds();
  updateTimerDisplay();
}

function waitForBatchToFinish() {
  return new Promise((resolve) => {
    const poll = setInterval(async () => {
      try {
        const response = await fetch("/get-status/", {
          method: "GET",
          credentials: "same-origin",
          headers: {
            "X-Requested-With": "XMLHttpRequest",
          },
        });

        const data = await response.json();

        if (!data.running) {
          clearInterval(poll);
          resolve();
        }
      } catch (error) {
        clearInterval(poll);
        resolve();
      }
    }, 3000);
  });
}

async function startTimerLoop() {
  stopTimerLoop();
  timerWasStoppedManually = false;

  timerDurationSeconds = getSelectedDurationSeconds();
  if (timerDurationSeconds <= 0) {
    addLog("Timer value must be greater than 0");
    return;
  }

  timerRemainingSeconds = timerDurationSeconds;
  autoCycleEnabled = true;
  timerRunning = true;
  updateTimerDisplay();
  addLog("Timer started");

  const tick = async () => {
    if (!autoCycleEnabled) {
      stopTimerLoop();
      return;
    }

    timerRemainingSeconds -= 1;

    if (timerRemainingSeconds <= 0) {
      timerRemainingSeconds = 0;
      updateTimerDisplay();
      stopTimerLoop();

      try {
        const result = await postAction("/start-script/");
        addLog(result.status);
        await waitForBatchToFinish();
      } catch (error) {
        addLog("Batch start failed");
        console.error(error);
      }

      if (!timerWasStoppedManually) {
        startTimerLoop();
      }
      return;
    }

    updateTimerDisplay();
  };

  timerInterval = setInterval(tick, 1000);
}

// === Refresh Status ===
async function getStats() {
  try {
    const response = await fetch("/get-stats/", {
      method: "GET",
      credentials: "same-origin",
      headers: {
        "X-Requested-With": "XMLHttpRequest",
      },
    });

    if (!response.ok) {
      throw new Error(`Stats request failed: ${response.status}`);
    }

    return await response.json();
  } catch (e) {
    console.error("getStats error:", e);
    return { scripts: [] };
  }
}

async function refreshStatus() {
  try {
    const statusResp = await fetch("/get-status/", {
      method: "GET",
      credentials: "same-origin",
      headers: {
        "X-Requested-With": "XMLHttpRequest",
      },
    });

    if (!statusResp.ok) {
      throw new Error(`Status request failed: ${statusResp.status}`);
    }

    const statusData = await statusResp.json();

    batchState.textContent = statusData.current || "idle";
    modemState.textContent = statusData.running ? "RUNNING" : "READY";
    progressValue.textContent = statusData.progress || "0/0";

    if (Array.isArray(statusData.logs)) {
      for (let i = lastLogCount; i < statusData.logs.length; i++) {
        addLog(statusData.logs[i]);
      }
      lastLogCount = statusData.logs.length;
    }

    // Fetch stats (collected / pushed per script)
    const statsData = await getStats();
    const scriptStats = statsData.scripts || [];

    const running = statusData.running;

    // Generate status table rows
    const rows = scriptStats.map(s => {
      const name = s.name || "unknown";
      const collected = s.collected || 0;
      const pushed = s.pushed || 0;

      return `
        <tr>
          <td>${name}</td>
          <td>
            <span class="badge ${running ? "running" : "completed"}">
              ${running ? "Running" : "Completed"}
            </span>
          </td>
          <td>---</td>
          <td>${statusData.progress || "0/0"}</td>
          <td>${collected}</td>
          <td>${pushed}</td>
        </tr>
      `;
    }).join("");

    statusTableBody.innerHTML = rows;
  } catch (error) {
    addLog("Failed to refresh status");
    console.error(error);
  }
}

async function refreshCpuUsage() {
  try {
    const response = await fetch("/system-metrics/", {
      method: "GET",
      credentials: "same-origin",
      headers: {
        "X-Requested-With": "XMLHttpRequest",
      },
    });

    if (!response.ok) {
      throw new Error(`CPU request failed: ${response.status}`);
    }

    const data = await response.json();

    if (cpuValue) {
      cpuValue.textContent = `${data.cpu_usage}%`;
    }
  } catch (error) {
    if (cpuValue) {
      cpuValue.textContent = "--%";
    }
    console.error(error);
  }
}

async function handleAction(action) {
  if (action === "start-all") {
    const result = await postAction("/start-script/");
    addLog(result.status);
    await refreshStatus();
    return;
  }

  if (action === "stop-all") {
    stopTimerManually();
    const result = await postAction("/stop-script/");
    addLog(result.status);
    await refreshStatus();
    return;
  }

  if (action === "refresh") {
    await refreshStatus();
    addLog("Status refreshed");
    return;
  }

  // Manual Modem Reboot
  if (action === "reboot") {
    try {
      const result = await postAction("/run-modem/");
      addLog(`Modem: ${result.status}`);
    } catch (error) {
      addLog("Modem reboot failed");
      console.error(error);
    }
    return;
  }

  // Manual Compiler run
  if (action === "run-compiler") {
    try {
      const result = await postAction("/run-compiler/");
      addLog(`Compiler: ${result.status}`);
    } catch (error) {
      addLog("Compiler failed");
      console.error(error);
    }
    return;
  }

  if (action === "timer-start") {
    await startTimerLoop();
    return;
  }

  if (action === "timer-stop") {
    stopTimerManually();
    return;
  }

  addLog(`${action} triggered`);
}

// === Event Listeners ===
document.addEventListener("DOMContentLoaded", () => {
  // Buttons with data-action
  document.querySelectorAll("[data-action]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const action = btn.dataset.action;
      try {
        await handleAction(action);
      } catch (error) {
        addLog("Action failed");
        console.error(error);
      }
    });
  });

  // Individual script cards
  if (scriptGrid) {
    scriptGrid.addEventListener("click", async (e) => {
      const btn = e.target.closest(".script-card");
      if (!btn) return;

      const scriptName = btn.dataset.script;
      if (!scriptName) return;

      try {
        addLog(`${scriptName} clicked`);
        const result = await postAction(
          `/start-script/?script=${encodeURIComponent(scriptName)}`
        );
        addLog(result.status || `${scriptName} started`);
        await refreshStatus();
      } catch (error) {
        addLog(`Failed to start ${scriptName}`);
        console.error(error);
      }
    });
  }

  // Config buttons
  if (saveConfigBtn) {
    saveConfigBtn.addEventListener("click", saveConfigToStorage);
  }

  if (loadConfigBtn) {
    loadConfigBtn.addEventListener("click", loadConfigFromStorage);
  }

  // Timer inputs
  timerInput?.addEventListener("change", () => {
    if (timerRunning) {
      startTimerLoop();
    } else {
      timerRemainingSeconds = getSelectedDurationSeconds();
      updateTimerDisplay();
    }
  });

  timerUnit?.addEventListener("change", () => {
    if (timerRunning) {
      startTimerLoop();
    } else {
      timerRemainingSeconds = getSelectedDurationSeconds();
      updateTimerDisplay();
    }
  });

  // Load config on page load
  loadConfigFromStorage();
});

// Poll status + CPU
setInterval(refreshStatus, 3000);
setInterval(refreshCpuUsage, 3000);

// Initial load
refreshStatus();
refreshCpuUsage();