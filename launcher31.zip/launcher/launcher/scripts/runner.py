import subprocess
import os
import time
import threading
import glob
import json

# --- STATS FILES (frontend + Compiler can read these) ---

BASE_SCRIPT_STATS = r"C:\Users\Akhil\Desktop\Vikrant\data\repo\scraper_stats.json"
BASE_ZOHOO_STATS = r"C:\Users\Akhil\Desktop\Vikrant\data\repo\zoho_stats.json"


BASE_DIR = r"C:\Users\Akhil\Desktop\Vikrant\operation"
compiler_script = "Compiler.py"
modem_script = "modem_reboot.py"


# ✅ NEW: Path to scraper output folder (update this to match your OUTPUT_PATH)
SCRAPER_OUTPUT_DIR = r"C:\Users\Akhil\Desktop\Vikrant\data\input"
SCRAPER_DONE_FILE = os.path.join(SCRAPER_OUTPUT_DIR, "scraper_done.txt")


process_status = {
    "running": False,
    "logs": [],
    "current": "idle",
    "progress": "0/0"
}


processes = {}
compiler_process = None
modem_process = None
process_lock = threading.Lock()
creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)


# --- PER‑SCRIPT STATS (runner + frontend will read these) ---
_SCRIPT_STATS = {}


def _load_stats():
    global _SCRIPT_STATS
    try:
        with open(BASE_SCRIPT_STATS, "r", encoding="utf-8") as f:
            _SCRIPT_STATS = json.load(f)
    except:
        _SCRIPT_STATS = {}


def _save_stats():
    try:
        os.makedirs(os.path.dirname(BASE_SCRIPT_STATS), exist_ok=True)
        with open(BASE_SCRIPT_STATS, "w", encoding="utf-8") as f:
            json.dump(_SCRIPT_STATS, f, indent=2)
    except Exception as e:
        print(f"!! Failed to save stats: {e}")


def log(msg):
    with process_lock:
        process_status["logs"].append(str(msg).rstrip())
        if len(process_status["logs"]) > 200:
            process_status["logs"].pop(0)


def detect_scripts():
    files = glob.glob(os.path.join(BASE_DIR, "*.py"))
    scripts = [
        os.path.basename(f)
        for f in files
        if os.path.basename(f) not in [compiler_script, modem_script]
    ]
    # Ensure stats dict has all scripts
    for script in scripts:
        if script not in _SCRIPT_STATS:
            _SCRIPT_STATS[script] = {"collected": 0, "pushed": 0}
    return scripts


# Load script stats at module level
_load_stats()
detect_scripts()


def _terminate_process(p):
    if p and p.poll() is None:
        try:
            p.terminate()
            try:
                p.wait(timeout=5)
            except subprocess.TimeoutExpired:
                p.kill()
        except Exception:
            pass


def _read_process_output(script_name, proc):
    try:
        # Read raw bytes from stdout
        for line in iter(proc.stdout.readline, b""):
            if not line:
                break
            # Try UTF-8 first, fallback to cp1252
            try:
                text = line.decode("utf-8", errors="replace")
            except Exception:
                text = line.decode("cp1252", errors="replace")
            text = text.rstrip()
            log(f"[{script_name}] {text}")

            # --- parse “collected” from scraper log line (example) ---
            # Example log: "[Inf - Insta creeper.py] Saved 1418 records to Inf - Insta.csv"
            if script_name in text:
                import re
                match = re.search(r"Saved (\d+) records to", text)
                if match:
                    count = int(match.group(1))
                    with process_lock:
                        if script_name not in _SCRIPT_STATS:
                            _SCRIPT_STATS[script_name] = {"collected": 0, "pushed": 0}
                        _SCRIPT_STATS[script_name]["collected"] = count
                        _save_stats()

    except Exception as e:
        log(f"[{script_name}] log read error: {e}")
    finally:
        try:
            proc.stdout.close()
        except Exception:
            pass


def _popen_script(script_name):
    # Run script with UTF-8 enabled, do not use text=True
    p = subprocess.Popen(
        ["python", "-X", "utf8", os.path.join(BASE_DIR, script_name)],
        cwd=BASE_DIR,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        # text=True removed → we'll decode manually in UTF-8 below
        universal_newlines=False,  # keep bytes mode
        bufsize=1,
        creationflags=creationflags,
        env={
            **os.environ,
            "PYTHONIOENCODING": "utf-8",
        },
    )
    threading.Thread(
        target=_read_process_output,
        args=(script_name, p),
        daemon=True
    ).start()
    return p


def run_scraper(target_script=None):
    global compiler_process, modem_process

    with process_lock:
        process_status["logs"] = []
        process_status["running"] = True
        process_status["current"] = "starting"
        process_status["progress"] = "0/0"

    scripts = detect_scripts()

    if target_script:
        scripts = [s for s in scripts if s == target_script]
        if not scripts:
            log(f"Script {target_script} not found")
            with process_lock:
                process_status["running"] = False
                process_status["current"] = "idle"
                process_status["progress"] = "0/0"
            return

    total = len(scripts)
    completed = 0
    active_processes = []

    # ✅ Start all scraper scripts
    for script in scripts:
        if not process_status["running"]:
            break

        log(f"Starting {script}")
        try:
            p = _popen_script(script)
            processes[script] = p
            active_processes.append((script, p))
        except Exception as e:
            log(f"Failed to start {script}: {e}")

        time.sleep(5)

    # ✅ Wait for all scraper processes to finish
    while active_processes and process_status["running"]:
        for script, p in active_processes[:]:
            rc = p.poll()
            if rc is not None:
                active_processes.remove((script, p))
                completed += 1
                with process_lock:
                    process_status["progress"] = f"{completed}/{total}"
                    process_status["current"] = f"Completed {script}"
                log(f"Completed {script}")

        time.sleep(1)

    if not process_status["running"]:
        with process_lock:
            process_status["current"] = "idle"
        return

    # ✅ NEW: Wait for scraper_done.txt before starting compiler
    if not target_script:
        log("Waiting for scraper completion file...")
        while process_status["running"] and not os.path.exists(SCRAPER_DONE_FILE):
            time.sleep(2)
            log(f"Still waiting for {os.path.basename(SCRAPER_DONE_FILE)}...")

        if os.path.exists(SCRAPER_DONE_FILE):
            log("Scraper done file found - launching Compiler...")
        else:
            log("Scraper done file NOT found - skipping compiler!")

        # Launch compiler only after done file exists
        try:
            compiler_process = _popen_script(compiler_script)
            compiler_process.wait()
            log("Compiler completed")
        except Exception as e:
            log(f"Compiler failed: {e}")

        log("Rebooting modem...")
        try:
            modem_process = _popen_script(modem_script)
            modem_process.wait()
            log("Modem reboot completed")
        except Exception as e:
            log(f"Modem reboot failed: {e}")

    log("Batch completed")
    with process_lock:
        process_status["running"] = False
        process_status["current"] = "idle"
        process_status["progress"] = f"{completed}/{total}"


def start_all_scripts(target_script=None):
    if process_status["running"]:
        return {"status": "already running"}

    threading.Thread(target=run_scraper, args=(target_script,), daemon=True).start()
    return {"status": "started"}


def stop_all_scripts():
    global compiler_process, modem_process

    with process_lock:
        process_status["running"] = False
        process_status["current"] = "idle"
        log("Stopping all processes...")

    for p in list(processes.values()):
        _terminate_process(p)

    _terminate_process(compiler_process)
    _terminate_process(modem_process)

    processes.clear()
    compiler_process = None
    modem_process = None

    log("All processes stopped")
    return {"status": "stopped"}


def get_process_status():
    return process_status


def run_compiler():
    global compiler_process

    if process_status["running"]:
        return {"status": "batch_running"}

    log("Manual Compiler run requested")

    try:
        compiler_process = _popen_script(compiler_script)
        compiler_process.wait()
        log("Compiler completed")
        return {"status": "compiler_done"}
    except Exception as e:
        log(f"Compiler failed: {e}")
        return {"status": "error", "message": str(e)}


def run_modem():
    global modem_process

    if process_status["running"]:
        return {"status": "batch_running"}

    log("Manual Modem reboot requested")

    try:
        modem_process = _popen_script(modem_script)
        modem_process.wait()
        log("Modem reboot completed")
        return {"status": "modem_done"}
    except Exception as e:
        log(f"Modem reboot failed: {e}")
        return {"status": "error", "message": str(e)}